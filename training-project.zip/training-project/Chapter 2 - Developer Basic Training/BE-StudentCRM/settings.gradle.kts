rootProject.name = "BE-StudentCRM"
