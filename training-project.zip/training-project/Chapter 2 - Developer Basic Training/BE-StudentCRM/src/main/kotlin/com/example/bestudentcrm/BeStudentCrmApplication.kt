package com.example.bestudentcrm

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class BeStudentCrmApplication

fun main(args: Array<String>) {
    runApplication<BeStudentCrmApplication>(*args)
}
