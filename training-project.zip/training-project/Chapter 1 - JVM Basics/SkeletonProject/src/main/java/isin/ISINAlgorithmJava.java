package isin;

import org.jetbrains.annotations.NotNull;

import java.util.Vector;

public class ISINAlgorithmJava {

    public static void main(String[] args) {
        ISINAlgorithmJava isinCalculator = new ISINAlgorithmJava();
        int proofNumber = isinCalculator.proveISIN("DE000LB0CGJ");
        System.out.println("Proof Number: " + proofNumber);
    }

    public int proveISIN(@NotNull String rawIsin) {
        Vector<Integer> isinVector = new Vector<>();
        String correctISIN = rawIsin.toUpperCase();
        char[] charIsin = rawIsin.toUpperCase().toCharArray();

        for (int i = 0; i < correctISIN.length(); i++) {
            boolean isDigit = Character.isDigit(correctISIN.charAt(i));
            if (!isDigit) {
                int numberAtIndexI = charIsin[i] - 55;
                isLetter(isinVector, numberAtIndexI);
            } else {
                int charIsinInteger = charIsin[i] - 48;
                isinVector.addElement(charIsinInteger);
            }
        }

        int[] weight = new int[isinVector.size()];
        int temp = 2;
        for (int i = isinVector.size() - 1; i >= 0; i--) {
            if (temp == 2) {
                weight[i] = 2;
                temp--;
            } else {
                weight[i] = 1;
                temp++;
            }
        }

        Vector<Integer> product = new Vector();
        for (int i = 0; i < isinVector.size(); i++) {
            int isinVectorInteger = isinVector.get(i);
            product.addElement(isinVectorInteger * weight[i]);
        }

        int crossSum = 0;
        Vector<Integer> singleNumbers = new Vector<>();

        //Vector product has single and double digit, has to be separated into only single digits
        for (int i = 0; i < product.size(); i++) {
            if (product.get(i) > 9) {
                singleNumbers.addElement(product.get(i) / 10);
                singleNumbers.addElement(product.get(i) % 10);
            } else {
                singleNumbers.addElement(product.get(i) % 10);
            }
        }

        for (int i = 0; i < singleNumbers.size(); i++) {
            crossSum = crossSum + singleNumbers.get(i);
        }


        int modulo = crossSum % 10;
        int proofNumber = 10 - modulo;
        if (proofNumber == 10) {
            proofNumber = 0;
        }

        return proofNumber;


    }

    private void isLetter(Vector<Integer> isinVector, int numberAtIndexI) {
        String numberString = String.valueOf(numberAtIndexI);                   //Convert
        char[] temp = numberString.toCharArray();
        int temp1 = temp[0] - 48;
        int temp2 = temp[1] - 48;
        isinVector.addElement(temp1);
        isinVector.addElement(temp2);
    }


}
