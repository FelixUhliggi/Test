package exercise2.task2_4;

public class WhatMonth {

    public static void main(String[] args) {
        byte month = 8;

        if(month == 12 || month <=2){
            System.out.println("It's winter");
        } else if(month <= 5){
            System.out.println("It's spring");
        } else if(month <= 8){
            System.out.println("It's summer");
        } else if(month <= 11){
            System.out.println("It's autumn");
        }



    }
}