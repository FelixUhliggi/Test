package exercise2.task2_5;

public class SmallGame {

    public static void main(String[] args) {

        double randomNumber = Math.random() * 100;
        System.out.println("I think of a number between 1 and 100");
        System.out.println("Whichever of you guesses closer wins.");
        double player1 = 18;
        System.out.println("Player 1, your number is " + player1);
        double player2 = 69;
        System.out.println("Player 2, your number is " + player2);
        System.out.println("Thank you very much! I will now compare your numbers with my with mine.");
        double differencePlayer1;
        if(player1 > randomNumber){
            differencePlayer1 = player1 - randomNumber;
        } else {
            differencePlayer1 = randomNumber - player1;
        }
        double differencePlayer2;
        if(player2 > randomNumber){
            differencePlayer2 = player2 - randomNumber;
        } else {
            differencePlayer2 = randomNumber - player2;
        }
        if (differencePlayer1 > differencePlayer2){
            System.out.println("Since my number was " + randomNumber + ", player 2 has won");
            System.out.println("Congratulations!");
        }else if (differencePlayer1 < differencePlayer2){
            System.out.println("Since my number was " + randomNumber + ", player 1 has won");
            System.out.println("Congratulations!");
        }else {
            System.out.println("Both of you have the same difference to my number " + randomNumber + " and therefore both of you win!");
            System.out.println("Congratulations!");
        }
    }
}