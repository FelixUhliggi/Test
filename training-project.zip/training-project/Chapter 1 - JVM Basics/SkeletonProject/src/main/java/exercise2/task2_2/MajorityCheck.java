package exercise2.task2_2;

public class MajorityCheck {

    public static void main(String[] args) {

        byte ageOfMajority = 18;
        byte ownAge = 19;

        if (ownAge >= ageOfMajority){
            System.out.println("You are of legal age");
        }
        else{
            System.out.println("You are not of legal age");
        }

    }
}