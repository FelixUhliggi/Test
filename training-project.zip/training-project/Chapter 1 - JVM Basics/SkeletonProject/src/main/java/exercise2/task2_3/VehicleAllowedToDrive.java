package exercise2.task2_3;

public class VehicleAllowedToDrive {

    public static void main(String[] args) {
        byte ownAge = 15;

        if(ownAge < 15){
            System.out.println("You are only allowed to ride a bike");
        } else if(ownAge >= 15){
            System.out.println("You may ride a moped");
        } else if(ownAge >= 16){
            System.out.println("You may ride a scooter");
        } else if(ownAge >= 18){
            System.out.println("You may ride a car");
        }



    }
}