package exercise2.task2_1;

public class task2_1 {

    public static void main(String[] args) {

        int number1 = 8;
        int number2 = 8;


    //a
        if (number1 == number2){
            System.out.println("The number " + number1 + " was entered twice");
        }
        else {
            System.out.println("The numbers " + number1 + " and " + number2 + " are not equal");
        }


    //a.i + a.ii
        if (number1 > number2){
            System.out.println("The number " + number1 + " is bigger than the number " + number2);
        }
        else if (number1 == number2){
            System.out.println("The number " + number1 + " was entered twice");
        }
        else {
            System.out.println("The number " + number1 + " is smaller than the number " + number2);
        }


    //a.iii + a.iv
        if (number1 >= number2){
            System.out.println("The number " + number1 + " is greater than or equal to the number " + number2);
        }
        else if (number1 == number2){
            System.out.println("The number " + number1 + " was entered twice");
        }
        else {
            System.out.println("The number " + number1 + " is smaller than or equal to the number " + number2);
        }


    //a.v
        if (number1 != number2){
            System.out.println("The number " + number1 + " is not the same as the number  " + number2);
        }
        else {
            System.out.println("The number " + number1 + " was entered twice");
        }


    }


}