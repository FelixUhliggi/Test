package exercise12.task12_1;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        ArrayList<String> names = new ArrayList<>();
        names.add("Felix");
        names.add("Paul");
        names.add("Felix");
        names.add("Paul");
        names.add("Felix");
        System.out.println(names);

        ArrayList<Person> personList = new ArrayList<>();
        Person pers1 = new Person("Felix", "9394823", 18);
        Person pers2 = new Person("Julian", "74329874", 21);
        personList.add(pers1);
        personList.add(pers2);
        System.out.println(personList);

    }

    public static class Person {
        String name, employeeNo;
        int age;

        public Person(String name, String employeeNo, int age) {
            this.name = name;
            this.employeeNo = employeeNo;
            this.age = age;
        }

        @Override
        public String toString() {
            return "[Person: " +
                    "Name='" + name + '\'' +
                    ", EmployeeNumber='" + employeeNo + '\'' +
                    ", Age=" + age + "]";
        }
    }
}
