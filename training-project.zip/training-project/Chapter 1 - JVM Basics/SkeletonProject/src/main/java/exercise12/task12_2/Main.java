package exercise12.task12_2;

import java.util.HashMap;

public class Main {
    public static void main(String[] args) {


        HashMap<String, Integer> directory = new HashMap<>();
        directory.put("Felix", 48332);
        directory.put("Julian", 24321);
        directory.put("Paul", 65432);
        directory.put("Marcel", 85632);
        directory.put("Olaf", 96723);
        System.out.println(directory);
    }
}