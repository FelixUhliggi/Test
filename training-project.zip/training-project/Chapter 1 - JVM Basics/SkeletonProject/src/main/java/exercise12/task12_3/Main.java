package exercise12.task12_3;

import java.util.TreeSet;

public class Main {
    public static void main(String[] args) {
        TreeSet<String> names = new TreeSet<>();
        names.add("Felix");
        names.add("Paul");
        names.add("Marcel");
        names.add("Olaf");
        names.add("Felix");
        names.add("Julian");
        System.out.println(names);
    }
}
