package exercise13.task13_2;
public class PasswordMain {
    public static void main(String[] args) {
        Password pass1 = new Password("Moini");
        pass1.outputPassword();
        pass1.changePassword("Hallor3r2323");
        pass1.outputPassword();

    }
}
