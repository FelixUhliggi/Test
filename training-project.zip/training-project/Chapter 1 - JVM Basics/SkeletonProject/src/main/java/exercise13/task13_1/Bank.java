package exercise13.task13_1;

class IllegalOverdraftException extends Exception {
    @Override
    public String toString() {
        return "Not possible, you have reached your overdraft limit! \nYour account balance is still: ";

    }
}


public class Bank {
    private static final int DISPOLIMIT = -1000;
    double accountBalance;

    public Bank(double accountBalance) {
        this.accountBalance = accountBalance;
    }

    void deposit(double amount) {

    }

    void withdraw(double amount) {

        try {
            if (accountBalance - amount < DISPOLIMIT) {
                throw new IllegalOverdraftException();
            } else {
                accountBalance = accountBalance - amount;
                System.out.println("Transaction completed");
                System.out.println("Your account balance is now: " + accountBalance);
            }
        } catch (IllegalOverdraftException e) {
            System.out.print(e);
            System.out.println(accountBalance);
        }

    }

    void accountBalanceQuery() {

    }
}
