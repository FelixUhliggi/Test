package exercise13.task13_1;

public class BankMain {
    public static void main(String[] args) {
        Bank bank1 = new Bank(1000);
        bank1.withdraw(2000);
    }
}
