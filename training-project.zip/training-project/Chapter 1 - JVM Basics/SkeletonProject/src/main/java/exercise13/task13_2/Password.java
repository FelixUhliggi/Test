package exercise13.task13_2;
public class Password {
    String password;

    void outputPassword(){
        try{
            if (password.length() > 10){
                throw new TooLongPasswordException("Password contains more than 10 letters! ");
            }
            else{
                System.out.println("Your Password is: " + password);
            }
        }
        catch (TooLongPasswordException e){
            System.out.println(e);
        }
    }
    void changePassword(String newPassword){
        this.password = newPassword;

        try{
            if (password.length() > 10){
                throw new TooLongPasswordException("Password contains more than 10 letters! ");
            }
            else{
                System.out.println("Your Password was changed! ");
            }
        }
        catch (TooLongPasswordException e){
            System.out.println(e);
        }
    }

    public Password(String password){
        this.password = password;
    }
}

class TooLongPasswordException extends Exception{
    /*@Override
    public String toString() {
        return "Exception: Your Password contains more than 10 characters! Try again!";
    }*/

    public TooLongPasswordException(String string){
        super(string);
    }
}