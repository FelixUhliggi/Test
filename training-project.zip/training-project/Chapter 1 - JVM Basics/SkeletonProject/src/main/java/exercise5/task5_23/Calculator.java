package exercise5.task5_23;

public class Calculator {

    static double getSum(double num1, double num2) {
        return num1 + num2;
    }

    static double getDifference(double num1, double num2) {
        return num1 - num2;
    }

    static double getProduct(double num1, double num2) {
        return num1 * num2;
    }

    static double getQuotient(double num1, double num2) {
        return num1 / num2;
    }

    public static void main(String[] args) {

        double num1 = 3;
        String operator = "/";
        double num2 = 5;

        switch (operator) {

            case "+":
                System.out.println(num1 + " " + operator + " " + num2 + " = " + getSum(num1, num2));
                break;
            case "-":
                System.out.println(num1 + " " + operator + " " + num2 + " = " + getDifference(num1, num2));
                break;
            case "*":
                System.out.println(num1 + " " + operator + " " + num2 + " = " + getProduct(num1, num2));
                break;
            case "/":
                System.out.println(num1 + " " + operator + " " + num2 + " = " + getQuotient(num1, num2));
                break;
        }

    }
}
