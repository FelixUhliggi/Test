package exercise5.task5_3;

public class PowerCalculation {

    public static void main(String[] args) {
        int num1 = 5;
        int num2 = 3;
        double result = getPotence(num1, num2);
        System.out.println(result);
    }
    static double getPotence(int num1, int num2){
        return Math.pow(num1, num2);

    }
}
