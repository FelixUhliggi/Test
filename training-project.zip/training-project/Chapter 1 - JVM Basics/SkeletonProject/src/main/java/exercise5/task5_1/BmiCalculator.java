package exercise5.task5_1;

public class BmiCalculator {

    static String getBMI(double bodyWeight, double bodyHeight){
        double bmi = bodyWeight / (bodyHeight * bodyHeight);
        return "Der BMI beträgt: " + bmi;
    }

    public static void main(String[] args) {
        System.out.println(getBMI(80, 1.9));
    }
}
