package exercise1;

public class task1_8 {

    public static void main(String[] args) {

        double radius = 5;
        double area = radius * radius * Math.PI;
        System.out.println("Der Radius beträgt " + area);


    }
}