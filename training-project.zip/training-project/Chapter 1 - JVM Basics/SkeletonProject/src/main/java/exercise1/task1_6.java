package exercise1;

public class task1_6 {

    public static void main(String[] args) {

        short num = 32;
        System.out.println(num);
        num = 356;
        System.out.println(num);
        // num = 400000;
        // System.out.println(num);
    }
}
