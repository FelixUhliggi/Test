package exercise1;

public class task1_7 {

    public static void main(String[] args) {

        int number1 = 5;
        int number2 = 10;
        final int number3 = 5;
        final int number4 = 10;
        number1 = 10;
        number2 = 20;
        //number3 = 10;
        //number 4 = 20;


    }
}