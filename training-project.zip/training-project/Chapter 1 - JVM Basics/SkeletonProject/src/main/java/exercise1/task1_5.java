package exercise1;

public class task1_5 {
    public static void main(String[] args) {

        System.out.println("Felix");
    }
}