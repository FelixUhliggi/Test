package astar;

import java.util.*;


public class AStar {
    int[][] maze;
    int startX;
    int startY;
    private boolean[][] closedSet;
    //boolean isObstacle = false;

    public AStar(int[][] maze, int startX, int startY, boolean b) {
        this.maze = maze;
        this.startX = startX;
        this.startY = startY;

    }


    public List<Node> findPathTo(int goalX, int goalY) {
        int numberOfRows = maze.length;
        int numberOfColumns = maze[0].length;
        PriorityQueue<Node> openSet = new PriorityQueue<>();

        Node startNode = new Node(startX, startY);
        startNode.g = 0;
        startNode.h = calculateHeuristic(startX, startY, goalX, goalY);
        openSet.add(startNode);
        this.closedSet = new boolean[numberOfRows][numberOfColumns];
        //HashMap<Object, Object> cameFrom = new HashMap<>();


        while (!openSet.isEmpty()) {
            Node currentNode = openSet.poll();
            closedSet[currentNode.x][currentNode.y] = true;


            if (currentNode.x == goalX && currentNode.y == goalY) {
                System.out.println("Ziel gefunden");
                return reconstructPath(currentNode);

            }

            //Neighbor right above the current Field
            if (currentNode.y > 0) {                                                            //check if current Y value is bigger than 0, because then there is a cell above the current
                if (!closedSet[currentNode.x][currentNode.y - 1]) {                             //if the closed Set doesn't contain the Neighbor Cell then...
                    Node neighborNode = new Node(currentNode.x, currentNode.y - 1);          //Create a new Node, neighborNode with new x and y values
                    checkNeighbors(goalX, goalY, openSet, currentNode, neighborNode);
                }

            }
            //Neighbor right
            if (currentNode.x < numberOfColumns - 1) {
                if (!closedSet[currentNode.x + 1][currentNode.y]) {
                    Node neighborNode = new Node(currentNode.x + 1, currentNode.y);
                    checkNeighbors(goalX, goalY, openSet, currentNode, neighborNode);
                }
            }
            //Neighbor down
            if (currentNode.y < numberOfRows - 1) {
                if (!closedSet[currentNode.x][currentNode.y + 1]) {
                    Node neighborNode = new Node(currentNode.x, currentNode.y + 1);
                    checkNeighbors(goalX, goalY, openSet, currentNode, neighborNode);
                }
            }
            //Neighbor left
            if (currentNode.x > 0) {
                if (!closedSet[currentNode.x - 1][currentNode.y]) {
                    Node neighborNode = new Node(currentNode.x - 1, currentNode.y);
                    checkNeighbors(goalX, goalY, openSet, currentNode, neighborNode);
                }
            }

            //Neighbor top right
            if (currentNode.x < numberOfColumns - 1 && currentNode.y > 0) {
                if (!closedSet[currentNode.x + 1][currentNode.y - 1]) {
                    Node neighborNode = new Node(currentNode.x + 1, currentNode.y - 1);
                    checkNeighbors(goalX, goalY, openSet, currentNode, neighborNode);
                }
            }

            //Bottom right
            if (currentNode.x < numberOfColumns - 1 && currentNode.y < numberOfRows - 1) {
                if (!closedSet[currentNode.x + 1][currentNode.y + 1]) {
                    Node neighborNode = new Node(currentNode.x + 1, currentNode.y + 1);
                    checkNeighbors(goalX, goalY, openSet, currentNode, neighborNode);
                }
            }

            //Top left
            if (currentNode.x > 0 && currentNode.y > 0) {
                if (!closedSet[currentNode.x - 1][currentNode.y - 1]) {
                    Node neighborNode = new Node(currentNode.x - 1, currentNode.y - 1);
                    checkNeighbors(goalX, goalY, openSet, currentNode, neighborNode);
                }
            }

            //Bottom left
            if (currentNode.x > 0 && currentNode.y < numberOfRows - 1) {
                if (!closedSet[currentNode.x - 1][currentNode.y + 1]) {
                    Node neighborNode = new Node(currentNode.x - 1, currentNode.y + 1);
                    checkNeighbors(goalX, goalY, openSet, currentNode, neighborNode);
                }
            }


        }
        return null;
    }


    private void checkNeighbors(int goalX, int goalY, PriorityQueue<Node> openSet, Node currentNode, Node neighborNode) {
        double movementCost = getMovementCost(currentNode.x, currentNode.y, neighborNode.x, neighborNode.y);//Create temporary G Value
        double tempG = currentNode.g + movementCost;
        if (closedSet[neighborNode.x][neighborNode.y] || movementCost > 30) {
            return;
        }
        if (openSet.contains(neighborNode)) {                                                                                               //If the openSet already contains the Neighbor Node
            Node existingNeighbor = openSet.stream().filter(n -> n.equals(neighborNode)).findFirst().get();
            if (tempG < existingNeighbor.g) {                                                                                                   //And the NeighborNode.g is bigger than temporary G
                existingNeighbor.g = tempG;                                                                                                 //Set the NeighborNode.g to the tempG
                existingNeighbor.parent = currentNode;
            }
        } else {                                                                                                                            //If it doesn't contain the NeighborNode
            neighborNode.g = tempG;                                                                                                         //Set the NeighborNode.g to the tempG
            openSet.add(neighborNode);                                                                                                      //And add the NeighborNode to the openSet
            neighborNode.h = calculateHeuristic(currentNode.x, currentNode.y, goalX, goalY);                                                                         //Calculate heuristic distance from Neighbor to Goal
            neighborNode.f = neighborNode.g + neighborNode.h;                                                                               //Calculate the F value of the Neighbor
            neighborNode.parent = currentNode;
        }
    }

    public double getMovementCost(int x1, int y1, int x2, int y2) {
        if (maze[y2][x2] == 100) {
            return Double.POSITIVE_INFINITY;
        } else {
            int dx = Math.abs(x2 - x1);
            int dy = Math.abs(y2 - y1);

            // Diagonale Bewegung ist teurer (ca. 1.4142...)
            if (dx == 1 && dy == 1) {
                return 14;
            } else {
                return 10;
            }

        }
    }


    public double calculateHeuristic(int x1, int y1, int x2, int y2) {
        // Verwende die euklidische Distanz, um die Entfernung zwischen den Zellen zu berechnen
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    }


    public static class Node implements Comparable<Node> {
        int x;
        int y;
        double f = 0;
        double g = 0;
        double h = 0;
        Node parent;


        public Node(int x, int y) {
            this.x = x;
            this.y = y;
        }

        @Override
        public int compareTo(Node other) {
            return Double.compare(this.g + this.h, other.g + other.h);
        }

    }

    public List<Node> reconstructPath(Node currentNode) {
        List<Node> path = new ArrayList<>();
        while (currentNode != null) {
            path.add(currentNode);
            currentNode = currentNode.parent;
        }
        Collections.reverse(path);
        return path;
    }

}
