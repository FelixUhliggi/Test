package exercise8.task8_1;

public class Name {

    public static void main(String[] args) {
        String[] names = new String[5];
        names[0] = "Jan";
        names[1] = "Katerina";
        names[2] = "Marcel";
        names[3] = "Olaf";
        names[4] = "Samuel";
        for (int i = 0; i< names.length; i++){
            System.out.println(names[i]);
        }
    }
}
