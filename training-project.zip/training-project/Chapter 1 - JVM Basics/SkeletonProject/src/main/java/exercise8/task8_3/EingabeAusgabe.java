package exercise8.task8_3;

import java.util.Scanner;

public class EingabeAusgabe {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the amount of numbers you want to add: ");
        int length = sc.nextInt();
        int[] numbers = new int[length];
        for (int i=0; i<length;i++){
            int sequence = i+1;
            System.out.print("Enter the " + sequence + ". number: ");
            numbers[i]=sc.nextInt();
        }
        for (int i=0; i<length;i++){
            System.out.print(numbers[i] + " ");
        }
        System.out.println(" ");
        System.out.println("Largest Number: " + getLargest(numbers));
    }

    public static int getLargest(int[] a) {
        int temp;
        //sort the array
        for (int i = 0; i < a.length; i++) {
            for (int j = i + 1; j < a.length; j++) {
                if (a[i] > a[j]) {
                    temp = a[i];
                    a[i] = a[j];
                    a[j] = temp;
                }
            }
        }
        //return largest element
        return a[a.length - 1];
    }
}
