package exercise8.task8_2;

public class PalindromeChecker {
    public static void main(String[] args) {
        String palindrome = "Kajak";
        char[] chars = palindrome.toLowerCase().toCharArray();
        int lastIndex = palindrome.length() - 1;
        boolean isPalindrome = true;
        for (int i = 0; i < palindrome.length() / 2; i++) {
            int reverse = lastIndex - i;
            if (chars[i] != chars[reverse]) {
                isPalindrome = false;
                System.out.println("The word " + palindrome + " is not a palindrome");
                break;
            }
        }
        if (isPalindrome) {
            System.out.println("The word " + palindrome + " is a palindrome");
        }
    }
}