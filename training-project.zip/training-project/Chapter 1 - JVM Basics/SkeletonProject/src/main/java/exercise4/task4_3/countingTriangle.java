package exercise4.task4_3;

public class countingTriangle {

    public static void main(String[] args) {
        String line = "";
        for (int i = 1; i<=9; i++){
            line =  line + i;
            System.out.println(line);

        }

        }
    }

