package exercise4.task4_2;

public class CountUpAndDivide {
    public static void main(String[] args) {
        for (int i=1; i<=100; i++){
            if (i % 3 == 0 && i % 4 == 0){
                System.out.println(i + " Divisible by 3 and 4");
            } else if (i % 3 == 0) {
                System.out.println(i + " Divisible by 3");
            } else if (i % 4 == 0) {
                System.out.println(i + " Divisible by 4");
            } else {
                System.out.println(i);
            }
        }
    }
}
