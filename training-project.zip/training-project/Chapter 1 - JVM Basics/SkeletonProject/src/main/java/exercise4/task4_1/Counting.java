package exercise4.task4_1;

public class Counting {

    //a
    public static void main(String[] args) {
        for (int i = 1; i <= 20; i++) {
            System.out.println(i);

        }
        int j = 1;
        while (j <= 20) {
            System.out.println(j);
            j++;
        }

        //b
        for (int n = 2; n <= 50; n = n + 2) {
            System.out.println(n);

        }


        //d
        for (int i = 1; i < 20; i++) {
            if (i > 10){
                System.out.print((20 - i) + " ");
            } else {
                System.out.print(i + " ");
            }

        }
    }
}