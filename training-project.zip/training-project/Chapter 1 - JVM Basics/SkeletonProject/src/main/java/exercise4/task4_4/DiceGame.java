package exercise4.task4_4;

public class DiceGame {

    public static void main(String[] args) {

        //a

        int tries = 1;
        int random = (int) (Math.random() * 6) + 1;
        while (random != 6) {

            System.out.println("Gewürfelt: " + random);
            random = (int) (Math.random() * 6) + 1;
            tries++;
        }
        System.out.println("Gewürfelt: " + random);
        System.out.println("Versuche: " + tries);

        }

    }
