package exercise4.task4_4;

public class DiceGame2 {

    public static void main(String[] args) {
        int tries = 0;
        int rolledsixes = 0;
        int random = (int) (Math.random() * 6) + 1;
        while (rolledsixes < 2) {
            if (random == 6) {
                rolledsixes++;
            } else {
                rolledsixes = 0;
            }
            System.out.println("Gewürfelt: " + random);
            random = (int) (Math.random() * 6) + 1;
            tries++;

        }
        System.out.println("Veruche: " + tries);
    }
}
