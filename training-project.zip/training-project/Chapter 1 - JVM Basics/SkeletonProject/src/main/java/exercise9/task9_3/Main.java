package exercise9.task9_3;

public class Main {

    public static void main(String[] args) {
        Bulb[] bulbChain = {new Bulb(), new Bulb(), new Bulb(), new Bulb(), new Bulb()};
        int tries = 0;

        for (int i=0; i<bulbChain.length; i++){
            tries++;
            while (bulbChain[i].isDamaged()){
                tries++;
                bulbChain[i] = new Bulb();
            }
            System.out.println("Bulb " + (i + 1) + " is now" + bulbChain[i]);

        }
        System.out.println(tries + " Bubs had to be changed until all were on");
    }
}
