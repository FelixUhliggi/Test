package exercise9.task9_3;

public class Bulb {

    private final boolean isDamaged = Math.random() < 0.5;

    public Bulb() {
    }

    private String getWorkingState() {
        if (isDamaged) {
            return " broken ";

        } else {
            return " working ";
        }
    }

    public boolean isDamaged() {
        return isDamaged;
    }

    public String toString() {
        return getWorkingState();

    }
}
