package exercise9.task9_1;

public class Person {
    String name; int age, weight, height;

    public Person(String name, int age, int weight, int height){
        this.name = name;
        this.age = age;
        this.weight = weight;
        this.height = height;
    }
    public String toString(){
        return "Name: " + name + ", Age: " + age + ", Weight: " + weight + ", Height:" + height;

    }

    boolean overMajorityAge() {
        return age >= 18;
    }



}
