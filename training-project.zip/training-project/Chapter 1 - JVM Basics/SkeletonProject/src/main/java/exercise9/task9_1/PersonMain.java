package exercise9.task9_1;

public class PersonMain {

    public static void main(String[] args) {
        Person1 pers1 = new Person1("Felix", 19, 80, 190);
        System.out.println("Over Majority Age: " + pers1.overMajorityAge());
        System.out.println(pers1);

    }
}
