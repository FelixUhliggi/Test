package exercise9.task9_2;

public class Customer1 {
    String name, fname;
    Address address;

    public Customer1(String name, String fname, Address address) {
        this.name = name;
        this.fname = fname;
        this.address = address;
    }

    public String toString() {
        return "Customer: " + fname + " " + name + "\n" + this.address.toString() + "\n";

    }

    public static class Address {
        String street, postcode, city;

        public String toString() {
            return "Address: " + street + ", " + postcode + " " + city;
        }

        public Address(String street, String postcode, String city) {
            this.street = street;
            this.postcode = postcode;
            this.city = city;

        }
    }


}