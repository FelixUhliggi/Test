package exercise9.task9_2;

public class CustomerMainJava {

    public static void main(String[] args) {
        Customer1.Address a1 = new Customer1.Address("Musterstr. 18", "32222", "Am See");
        Customer1 c1 = new Customer1("Mustermann", "Max", a1);

        Customer1.Address a2 = new Customer1.Address("Hauptbahnhof. 2", "43332", "City Center");
        Customer1 c2 = new Customer1("Schmidt", "Manfred", a2);

        Customer1.Address a3 = new Customer1.Address("Stuttgarter Weg 22", "23333", "Schlosspark");
        Customer1 c3 = new Customer1("Lee", "Lisa", a3);

        Customer1[] customers = {c1, c2, c3};

        for (int i = 0; i < customers.length; i++) {
            System.out.println("___Customer No." + (i + 1) + "___");
            System.out.println(customers[i].toString());
        }
    }
}
