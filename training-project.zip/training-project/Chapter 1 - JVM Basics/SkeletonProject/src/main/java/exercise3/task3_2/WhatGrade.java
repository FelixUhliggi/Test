package exercise3.task3_2;

public class WhatGrade {

    public static void main(String[] args) {
        String grade = "Very Good";

        switch (grade) {
            case "Very Good":
                System.out.println("Grade 1");
                break;
            case "Good":
                System.out.println("Grade 2");
                break;
            case "Satisfactory":
                System.out.println("Grade 3");
                break;
            case "Sufficient":
                System.out.println("Grade 4");
                break;
            case "Poor":
                System.out.println("Grade 5");
                break;
            case "Unsatisfactory":
                System.out.println("Grade 6");
                break;
        }
    }
}