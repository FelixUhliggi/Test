package exercise15.Search.task1;

class BinarySearch {
    static int[] mixed = {1, 2, 3, 4, 5};
    static int n = mixed.length;
    static int target = 6;

    public static void main(String[] args) {
        BinarySearch search1 = new BinarySearch();
        int result = search1.findElement(target, 0, n - 1);
        if (result == -1) {
            System.out.println("Target was not found");
        } else {
            System.out.println("Target was found at index: " + result);

        }
    }

    int findElement(int target, int left, int right) {

        if (right >= left && left <= mixed.length - 1) {

            int middle = left + (right - left) / 2;

            if (mixed[middle] == target)
                return middle;

            if (mixed[middle] > target)
                return findElement(target, left, middle - 1);

            return findElement(target, middle + 1, right);
        }
        return -1;
    }
}
