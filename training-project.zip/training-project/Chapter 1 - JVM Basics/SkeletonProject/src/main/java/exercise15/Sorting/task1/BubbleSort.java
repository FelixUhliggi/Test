package exercise15.Sorting.task1;

public class BubbleSort {
    public static void main(String[] args) {
        int[] nums = {9, 8, 7, 6, 5, 4, 3, 2, 1, 0};

        int temp;
        int current;
        int next;
        for (int i = 0; i < nums.length; i++) {
            System.out.print(nums[i] + " ");
        }
        System.out.println("\n");

        int lastIndex = nums.length - 1;
        for (int i = 0; i < lastIndex; i++) {
            for (int k = 0; k < lastIndex; k++) {
                if (nums[k] > nums[k + 1]) {
                    current = nums[k];
                    next = nums[k + 1];

                    temp = current;
                    current = next;
                    next = temp;

                    nums[k] = current;
                    nums[k + 1] = next;
                }
            }
            for (int j = 0; j < nums.length; j++) {
                System.out.print(nums[j] + " ");
            }
            System.out.println("\n");

        }
    }

}

