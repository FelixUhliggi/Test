package exercise11.task11_1

fun main() {
    var plane1 = Plane()
    plane1.currentLocation(100.0, 200.0)
    plane1.speed(40)
    plane1.destination("Spain")


}