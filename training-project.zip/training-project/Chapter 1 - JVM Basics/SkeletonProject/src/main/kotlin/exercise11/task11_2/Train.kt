package exercise11.task11_2

class Train : Driveable {
    override fun drive(x: Int) {
        println("Train is driving with $x km/h")
    }

    override fun brake(x: String) {
        println(x)

    }

}