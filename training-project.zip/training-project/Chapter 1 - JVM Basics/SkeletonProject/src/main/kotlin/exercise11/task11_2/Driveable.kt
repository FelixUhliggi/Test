package exercise11.task11_2

interface Driveable {
    fun drive(x: Int)
    fun brake(x: String)
}