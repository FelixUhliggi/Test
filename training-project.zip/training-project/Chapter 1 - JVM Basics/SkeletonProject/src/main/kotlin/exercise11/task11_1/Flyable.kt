package exercise11.task11_1

interface Flyable {
    fun currentLocation(x: Double, y: Double)
    fun speed(x: Int)
    fun destination(country: String)
}