package exercise11.task11_1

class Plane : Flyable {
    override fun currentLocation(x: Double, y: Double) {
        println("Current Location [$x|$y]")
    }

    override fun speed(x: Int) {
        println("Speed: $x km/h")
    }

    override fun destination(country: String) {
        println("Destination: $country")
    }


}