package exercise11.task11_2

class Car : Driveable {
    override fun drive(x: Int) {
        println("Car is driving with $x km/h")
    }

    override fun brake(x: String) {
        println(x)

    }
}