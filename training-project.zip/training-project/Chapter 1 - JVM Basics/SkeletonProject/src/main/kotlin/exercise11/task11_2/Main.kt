package exercise11.task11_2

fun main() {
    var train1 = Train()
    println(train1.brake("Choo-Choo"))
    println(train1.drive(5))
}