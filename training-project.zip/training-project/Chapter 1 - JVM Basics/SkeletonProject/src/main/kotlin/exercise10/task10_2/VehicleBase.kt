package exercise10.task10_2

open class VehicleBase(val tires: Int, val horsePower: Int) {

}