package exercise10.task10_1

data class Car(val tires: Int, val horsePower: Int) {
    var MotorID = "975467"

    override fun toString(): String = "Tires: $tires, Horsepower: $horsePower, Motor-ID: $MotorID"

}