package exercise10.task10_2

data class Truck(val tires: Int, val horsePower: Int) {
    var MotorID = "34256"

    override fun toString(): String = "Tires: $tires, Horsepower: $horsePower, Motor-ID: $MotorID"

}