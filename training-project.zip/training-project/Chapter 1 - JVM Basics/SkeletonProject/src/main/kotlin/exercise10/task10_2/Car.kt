package exercise10.task10_2

class Car(tires: Int, horsePower: Int) : VehicleBase(tires, horsePower) {
    var MotorID = "975467"

    override fun toString(): String = "Tires: $tires, Horsepower: $horsePower, Motor-ID: $MotorID"

}