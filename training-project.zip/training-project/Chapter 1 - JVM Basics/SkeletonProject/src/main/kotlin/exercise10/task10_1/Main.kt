package exercise10.task10_1

class Main {
}

fun main() {
    val bike1 = Motorcycle(2, 85)
    val car1 = Car(4, 250)
    val truck1 = Truck(6, 680)
    println(bike1)
    println(car1)
    println(truck1)
}