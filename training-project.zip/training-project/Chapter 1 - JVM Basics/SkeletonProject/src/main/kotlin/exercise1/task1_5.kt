package exercise1

fun main() {
    println("Felix!")
}