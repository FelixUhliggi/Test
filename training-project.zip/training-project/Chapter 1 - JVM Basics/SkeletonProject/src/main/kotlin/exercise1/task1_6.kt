package exercise1

fun main() {
    var myNumber: Short = 32;
    println(myNumber)
}