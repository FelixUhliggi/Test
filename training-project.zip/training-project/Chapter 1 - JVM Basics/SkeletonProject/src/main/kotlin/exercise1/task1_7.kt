package exercise1

const val myConst = 32;
const val myConst2 = 64;
fun main() {
    var myVariable = 32;
    var myVariable2 = 64;

}