package exercise1

import kotlin.math.PI

fun main() {
    var radius = 5
    var area = radius * radius * PI
    var circumference = 2 * radius * PI
    print("Area: " + area + " Circumference: " + circumference)
}