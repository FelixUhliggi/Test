package exercise9.task9_3

class BulbKotlin {
    private val randomNumber = Math.random()

    val isBroken = when {
        randomNumber > 0.5 -> true
        else -> false
    }

    override fun toString(): String {
        return when (isBroken) {
            true -> "Bulb is broken"
            false -> "Bulb works"
        }
    }
}