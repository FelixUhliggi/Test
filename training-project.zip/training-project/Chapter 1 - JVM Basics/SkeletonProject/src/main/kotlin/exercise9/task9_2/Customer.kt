package exercise9.task9_2

import kotlin.reflect.jvm.internal.impl.load.kotlin.JvmType

data class Customer(val customerNumber: Int, val name: String, val firstName: String, val address: Address) {
    override fun toString(): String = "___Customer No. ${customerNumber}___\n$firstName $name \n$address"

    data class Address(val street: String, val postcode: String, val city: String) {
        override fun toString(): String = "$street, $postcode $city"
    }

}