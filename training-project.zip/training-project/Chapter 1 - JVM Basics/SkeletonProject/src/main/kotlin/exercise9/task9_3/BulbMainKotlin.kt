package exercise9.task9_3

fun main() {
    var bulbChain = arrayOf(BulbKotlin(), BulbKotlin(), BulbKotlin(), BulbKotlin(), BulbKotlin())
    var allWorking = false
    var bulbsChanged = 0

    while (!allWorking) {
        allWorking = true
        for (i in bulbChain.indices) {
            println("${i + 1}: ${bulbChain[i]}")
            if (bulbChain[i].isBroken) {
                bulbsChanged++
                bulbChain[i] = BulbKotlin()
                allWorking = false
            }
        }
    }
    println("All are working again, only had to change $bulbsChanged bulbs")
}