package exercise9.task9_1

data class Person1(var name: String, var age: Int, var weight: Int, var height: Double) {

    fun overMajorityAge(): Boolean {
        return age >= 18
    }

    override fun toString(): String = "Name: $name, Age: $age Years, Weight: $weight Kilograms, Height: $height Meters"
}