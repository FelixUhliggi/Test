package exercise9.task9_1

fun main() {

    val pers1 = Person1("Paul", 18, 190, 1.7)

    println(pers1.overMajorityAge())
    println(pers1)
}