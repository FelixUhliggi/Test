package exercise9.task9_2

fun main() {

    val customer1 = Customer(1, "Max", "Mustermann", Customer.Address("Musterstraße 18", "32222", "Am See"))
    val customer2 = Customer(2, "Schmidt", "Manfred", Customer.Address("Hauptbahnhof. 2", "43332", "City Center"))
    val customer3 = Customer(3, "Lee", "Lisa", Customer.Address("Stuttgarter Weg 22", "23333", "Schlosspark"))

    var customer = arrayOf(customer1, customer2, customer3)

    for (i in customer)
        println("${i}\n")
}
