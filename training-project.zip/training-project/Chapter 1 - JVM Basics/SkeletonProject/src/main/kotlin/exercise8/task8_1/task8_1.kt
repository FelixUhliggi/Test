package exercise8.task8_1

fun main() {
    var names = arrayOf("Felix", "Katerina", "Jan", "Paul")
    for (i in names)
        println(i)
}