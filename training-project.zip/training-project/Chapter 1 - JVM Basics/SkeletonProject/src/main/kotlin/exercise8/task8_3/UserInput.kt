package exercise8.task8_3

import java.util.*

fun main() {
    val scanner = Scanner(System.`in`)
    print("Choose the size of the array: ")
    val arraySize: Int = (scanner.nextInt())
    var array = IntArray(arraySize)

    for (i in 0 until arraySize) {
        print("type index $i into Array: ")
        array[i] = scanner.nextInt()
    }
    var highestNumber = 0
    for (x in array) {
        if (highestNumber < x)
            highestNumber = x
        print("$x ")
    }
    println("\nHighest Number: $highestNumber")
}