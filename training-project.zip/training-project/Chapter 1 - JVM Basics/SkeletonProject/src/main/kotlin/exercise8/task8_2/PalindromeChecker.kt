package exercise8.task8_2

fun main() {
    val palindrome = "Anna"
    val chars = palindrome.toCharArray()
    val lastIndex = palindrome.length - 1
    var isPalindrome = false

    for (i in 0..palindrome.length / 2) {
        if (chars[i].equals(chars[lastIndex - i]))
            isPalindrome = true
    }
    println("Is a Palindrome: $isPalindrome")

}