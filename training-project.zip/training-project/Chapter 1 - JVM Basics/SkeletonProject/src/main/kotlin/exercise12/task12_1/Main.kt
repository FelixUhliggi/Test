package exercise12.task12_1

fun main() {
    val names: MutableList<String> = ArrayList()
    names.add("Felix")
    names.add("Paul")
    names.add("Katerina")
    names.add("Jannik")
    names.add("Marcel")
    for (i in names)
        println(i)

    val persons: MutableList<Person> = ArrayList()
    var person1 = Person("Felix", 18, 438623894)
    var person2 = Person("Paul", 32, 574534213)
    persons.add(person1)
    persons.add(person2)
    for (i in persons)
        println(i)
}

data class Person(var name: String, var age: Int, var employeedNumber: Int) {
    override fun toString(): String = "{Name: $name, Age: $age, Employee-Number: $employeedNumber}"


}