package exercise12.task12_3

import java.util.TreeSet

fun main() {
    val treeSet = TreeSet<String>()
    treeSet.add("Felix")
    treeSet.add("Paul")
    treeSet.add("Felix")        //only once
    treeSet.add("Olaf")
    treeSet.add("Marcel")

    for (i in treeSet)
        println(i)
}