package exercise12.task12_2

fun main() {
    val map = HashMap<String, Int>()
    map["Felix"] = 42873642
    map["Paul"] = 234123543
    map["Olaf"] = 856564435
    for (i in map)
        println(i)
}