package isin

import java.util.*

fun main() {
    val isinCalculator = ISINAlgorithmKotlin()
    val proofNumber = isinCalculator.proveISIN("DE000555750")
    println("Proof number: $proofNumber")
}


class ISINAlgorithmKotlin {
    fun proveISIN(rawIsin: String): Int {
        //Convert the rawIsin in a Char Array with only Uppercase
        val isinAsArray = rawIsin.uppercase().toCharArray()
        val isinAsDigitVector = Vector<Int>()
        for (i in isinAsArray) {
            if (i.isDigit()) isinAsDigitVector.add(i.toInt() - 48)
            else {
                val charAsDigit = i.toInt() - 55
                val char1 = charAsDigit / 10
                isinAsDigitVector.add(char1)
                val char2 = charAsDigit % 10
                isinAsDigitVector.add(char2)
            }
        }

        //Create Weight Array ...21212
        val weightArray = Vector<Int>()
        var temp = 2
        for (i in isinAsDigitVector.size - 1 downTo 0) {
            weightArray.add(temp)
            if (temp == 2) {
                temp = 1
            } else {
                temp = 2
            }

        }
        weightArray.reverse()

        //Calculating the product
        val product = Vector<Int>()
        for (i in 0 until isinAsDigitVector.size) {
            val vectorProduct: Int = (weightArray[i] * isinAsDigitVector[i])
            if (vectorProduct >= 10) {
                val digit1 = vectorProduct / 10
                product.add(digit1)
                val digit2 = vectorProduct % 10
                product.add(digit2)
            } else
                product.add(vectorProduct)

        }

        //Calculating the Cross Sum
        var crossSum = 0
        for (i in product)
            crossSum += i

        //Performing modulo
        val modulo = crossSum % 10
        var proofNumber = 10 - modulo
        if (proofNumber == 10) {
            proofNumber = 0
        }

        return proofNumber
    }
}