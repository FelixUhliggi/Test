package exercise5.task5_1

fun main() {
    var bodyWeight = 80
    var bodyHeight = 1.9
    println(calculateBMI(bodyWeight, bodyHeight))
}

fun calculateBMI(bodyWeight: Int, bodyHeight: Double): String {
    var bmi = bodyWeight / (bodyHeight * bodyHeight)
    return "BMI: $bmi"
}