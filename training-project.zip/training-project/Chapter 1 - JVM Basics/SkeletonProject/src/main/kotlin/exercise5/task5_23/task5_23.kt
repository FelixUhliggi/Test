package exercise5.task5_23

fun main() {
    var num1 = 5.0
    var operator = "^"
    var num2 = 2.0
    when (operator) {
        "+" -> sum(num1, num2)
        "-" -> difference(num1, num2)
        "*" -> product(num1, num2)
        "/" -> quotient(num1, num2)
        "^" -> potency(num1, num2)                  //task 5.3
    }

}

fun sum(x: Double, y: Double) = println(x + y)
fun difference(x: Double, y: Double) = println(x - y)
fun product(x: Double, y: Double) = println(x * y)
fun quotient(x: Double, y: Double) = println(x / y)
fun potency(x: Double, y: Double) = println(Math.pow(x, y))         //task 5.3
