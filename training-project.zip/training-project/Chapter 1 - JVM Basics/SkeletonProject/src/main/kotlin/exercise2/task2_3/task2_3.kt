package exercise2.task2_3

fun main() {
    var ownAge = 14
    var mopedAge = 15
    var scooterAge = 16
    var carAge = 18;
    if (ownAge < mopedAge)
        println("You are only allowed to ride a bike")
    if (ownAge >= mopedAge)
        println("You may ride a moped")
    if (ownAge >= scooterAge)
        println("You may ride a scooter")
    if (ownAge >= carAge)
        println("You may drive a car")
}