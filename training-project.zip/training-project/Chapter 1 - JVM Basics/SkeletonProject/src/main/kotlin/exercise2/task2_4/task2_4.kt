package exercise2.task2_4

fun main() {
    var month = 11
    if (month == 12 || month <= 2 && month >= 1)
        println("It's winter")
    if (month <= 5 && month >= 3)
        println("It's spring")
    if (month <= 8 && month >= 6)
        println("It's summer")
    if (month <= 11 && month >= 9)
        println("It's autumn")
    if (month < 1 || month > 12)
        println("This number is no month!")

}