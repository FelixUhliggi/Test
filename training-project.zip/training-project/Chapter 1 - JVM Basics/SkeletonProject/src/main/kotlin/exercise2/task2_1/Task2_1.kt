package exercise2.task2_1

fun main() {
    var number1 = 5;
    var number2 = 10;
    if (number1 == number2)
        println("The number " + number1 + "was entered twice.")
    if (number1 != number2)
        println("The numbers " + number1 + " and " + number2 + " are not equal.")
    if (number1 > number2)
        println("The number: " + number1 + " is greater than " + number2)
    if (number1 < number2)
        println("The number: " + number1 + " is less than " + number2)
    if (number1 >= number2)
        println("The number: " + number1 + " is greater than or equal to " + number2)
    if (number1 <= number2)
        println("The number: " + number1 + " is less than or equal to " + number2)


}