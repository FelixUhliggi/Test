package exercise2.task2_2

fun main() {
    var legalAge = 18;
    var ownAge = 18;
    if (ownAge >= legalAge)
        println("You are of legal age")
    else
        println("You are not of legal age")
}