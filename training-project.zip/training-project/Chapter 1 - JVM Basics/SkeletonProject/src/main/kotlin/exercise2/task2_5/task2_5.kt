package exercise2.task2_5

fun main() {
    var randomNumber = Math.random() * 100
    var number1 = 20
    var number2 = 60
    var number1D = Math.abs(randomNumber - number1)
    var number2D = Math.abs(randomNumber - number2)
    println("My Number is: " + randomNumber)
    if (number1D == number2D)
        println("Ihr habt genau den selben Abstand")
    if (number1D > number2D)
        println("Spieler 2 hat gewonnen")
    if (number1D < number2D)
        println("Spieler 1 hat gewonnen")
}