package exercise15.Search.task1


val list = arrayOf(1, 2, 3, 4, 5, 6, 7, 8, 9)
fun main() {
    val target = 10
    val search = findElement(target, 0, list.size - 1)
    if (search == -1) {
        println("Target was not found")
    } else
        println("Target was found at index: $search")
}

fun findElement(target: Int, left: Int, right: Int): Int {
    if (right >= left && left <= list.size - 1) {
        val middle: Int = left + (right - left) / 2
        if (list[middle] == target) return middle
        if (list[middle] > target) return findElement(target, left, middle - 1)
        return findElement(target, middle + 1, right)
    }

    return -1
}