package exercise15.Sort.task1


val list = arrayOf(1, 85, 4, 6, 9, 2, 40, 3, 32, 64)
val n = list.size
fun main() {
    print("Unsorted: ")
    for (i in list)
        print("$i, ")
    var swapped = false
    while (!swapped) {
        for (j in 1 until n) {
            for (i in 1 until n) {
                if (list[i - 1] > list[i]) {
                    val temp = list[i - 1]
                    list[i - 1] = list[i]
                    list[i] = temp
                    swapped = true
                }
            }
        }
    }
    print("\nSorted: ")
    for (i in list)
        print("$i, ")

}