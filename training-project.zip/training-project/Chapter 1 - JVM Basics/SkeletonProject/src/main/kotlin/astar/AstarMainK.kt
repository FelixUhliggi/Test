package astar

import AStarK
import java.util.function.Consumer

fun main() {
    val startColumn = 0             //Top to bottom
    val startRow = 0                //Left to right
    val goalColumn = 7
    val goalRow = 7

    val maze = arrayOf(
            arrayOf(0, 100, 0, 0, 0, 0, 0, 0),
            arrayOf(200, 0, 0, 0, 0, 0, 0, 0),
            arrayOf(0, 0, 0, 100, 100, 100, 0, 0),
            arrayOf(0, 0, 0, 0, 0, 100, 0, 0),
            arrayOf(0, 0, 100, 0, 0, 100, 0, 0),
            arrayOf(0, 0, 100, 0, 0, 100, 0, 0),
            arrayOf(0, 0, 100, 100, 100, 100, 0, 0),
            arrayOf(0, 0, 0, 0, 0, 0, 0, 0),
    )

    val asK = AStarK(maze, startColumn, startRow)
    val path = asK.findPathTo(goalColumn, goalRow)
    
}
