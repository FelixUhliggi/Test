data class AStarK(val maze: Array<Array<Int>>, val startColumn: Int, val startRow: Int) {

    fun findPathTo(goalColumn: Int, goalRow: Int): Int {
        val numberOfColumns = maze.size
        val numberOfRows = maze[0].size



        return 0
    }


}