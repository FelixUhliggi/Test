package exercise4.task4_3

fun main() {
    var line = ""
    for (i in 1..9) {
        line += i
        println(line)
    }

}