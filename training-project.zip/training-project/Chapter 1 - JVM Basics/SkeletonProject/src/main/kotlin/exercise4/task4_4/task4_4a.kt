package exercise4.task4_4

fun main() {
    //4a
    var isSix = false
    var tries = 1
    while (!isSix) {
        print("Try number: $tries | ")
        val random = (Math.random() * 6 + 1).toInt()
        println("Rolled: $random")
        if (random == 6)
            isSix = true
        else
            tries++
    }


}