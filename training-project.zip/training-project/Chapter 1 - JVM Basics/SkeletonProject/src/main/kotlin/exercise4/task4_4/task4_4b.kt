package exercise4.task4_4

fun main() {
    //4a
    var twoSix = false
    var tries = 1
    while (!twoSix) {
        print("Try number: $tries | ")
        var random = (Math.random() * 6 + 1).toInt()
        print("First Dice: $random")
        if (random == 6) {
            random = (Math.random() * 6 + 1).toInt()
            print(" | Second Dice: $random")
            if (random == 6)
                twoSix = true
        } else
            tries++
        println()
    }


}