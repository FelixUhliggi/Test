package exercise4.task4_2

fun main() {
    for (i in 1..100) {
        if (i % 3 == 0 && i % 4 == 0)
            println("Divisible by 3 and 4")
        else if (i % 3 == 0)
            println("Divisible by 3")
        else if (i % 4 == 0)
            println("Divisible by 4")
        else
            println(i)
    }
}