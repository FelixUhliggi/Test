package exercise4.task4_1

fun main() {
    //4.a
    for (i in 1..20) {
        println(i)
    }
    var i = 1
    while (i <= 20) {
        println(i)
        i++
    }

    //4.b
    var j = 0
    while (j <= 50) {
        println(j)
        j += 2
    }

    //4.d
    for (i in 1..19) {
        if (i < 10)
            print(" " + i)
        if (i >= 10)
            print(" " + (20 - i))
    }
}