package exercise3.task3_2

fun main() {
    var grade = "Good"
    when (grade) {
        "Very good" -> println("1")
        "Good" -> println("2")
        "Satisfactory" -> println("3")
        "Sufficient" -> println("4")
        "Poor" -> println("5")
        "Unsatisfactory" -> println("6")
    }
}