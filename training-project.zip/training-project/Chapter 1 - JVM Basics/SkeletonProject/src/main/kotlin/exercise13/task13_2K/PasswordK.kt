package exercise13.task13_2K

import exercise13.task13_1K.IllegalOverdraftExceptionK

data class PasswordK(var password: String) {
    fun outputPassword() {
        println("Your password is: $password")
    }

    fun changePassword(newPassword: String) {
        try {
            if (newPassword.length > 10)
                throw TooLongPasswordExceptionK()
            else {
                password = newPassword
                println("Password was changed!")
            }
        } catch (e: TooLongPasswordExceptionK) {
            println(e)
            println("Your password is still: $password")
        }


    }
}