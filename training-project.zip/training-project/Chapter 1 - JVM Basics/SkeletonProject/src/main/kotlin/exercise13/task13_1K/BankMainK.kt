package exercise13.task13_1K

fun main() {
    var bank1 = BankK()
    bank1.deposit(1000.0)
    bank1.withdraw(5000.0)
    bank1.accountBalanceQuery()

}