package exercise13.task13_1K

class BankK() {
    private val DISPOLIMIT = -1000
    private var accountBalance: Double = 2000.0

    fun deposit(amount: Double) {
        accountBalance += amount
    }

    fun withdraw(amount: Double) {
        try {
            if (accountBalance - amount < DISPOLIMIT)
                throw IllegalOverdraftExceptionK()
            else {
                accountBalance -= amount
                println("Transaction completed")
                println("Your account balance is now: $accountBalance")
            }
        } catch (e: IllegalOverdraftExceptionK) {
            println(e)
            println("Your account balance is still $accountBalance")
        }
    }

    fun accountBalanceQuery() {
        println("Your current account balance is: $accountBalance")
    }
}