package exercise13.task13_1K

class IllegalOverdraftExceptionK : Exception("You have reached your overdraft limit!")