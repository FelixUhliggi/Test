package exercise13.task13_2K

class TooLongPasswordExceptionK : Exception("The Password can't have more than 10 characters! ")