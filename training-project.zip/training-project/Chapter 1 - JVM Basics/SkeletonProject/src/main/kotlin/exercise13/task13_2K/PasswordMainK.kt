package exercise13.task13_2K

var password = ""
fun main() {
    var myPassword = PasswordK("Moin Meister")
    myPassword.outputPassword()
    myPassword.changePassword("483274823748")

}