package isin

import kotlin.test.assertEquals
import org.junit.jupiter.params.ParameterizedTest
import org.junit.jupiter.params.provider.CsvFileSource

class ISINAlgorithmKotlinTest {

    private val cut = ISINAlgorithmKotlin()

    @ParameterizedTest
    @CsvFileSource(resources = ["/isin_test_values.csv"], numLinesToSkip = 1)
    fun isinAlgorithmTest(expected: String, isin: String) {
        assertEquals(expected.toInt(), cut.proveISIN(isin))
    }
}
