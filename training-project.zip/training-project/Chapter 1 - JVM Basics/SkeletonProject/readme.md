# Chapter 1 Basic Java/Kotlin Training

## Project introduction
This skeleton project can be used to implement all the java and kotlin code that is needed to fulfill the Talent Hub Training Catalog.

All code that is related to JAVA  can be placed inside the folder/package: `src/main/java`. Kotlin related code is using the `src/main/kotlin` folder accordingly.

### Task/Folder Structuring
Please organize your tasks/implementations in a proper way. At some point you will need to add multiple classes for 1 task, so a individual package for a task should be the best fit.
- Package called `exercise1`: Contains all implementations related to the first amount of exercises.
- `task1_1` package contains all implementations needed to fulfil task number 1.1.
- The final and bigger exercises can be placed to `isin`, `aStar` and `encryption`.

### ISIN Testing (example)
The ISIN exercise does contain a parameterized unit test already. If you navigate to `src/test/java/isin` you can find the java version for example.

Unit tests are used to check a methods behavior and result. This one is just a pretty simple one that reads a CSV file and compares the calculated output with a defined expected result for a given ISIN.
Simply execute the test with the "play"-button if you want to test your application.
If you want to see some example results and raw isin data check the file `src/test/resources/isin_test_values.csv`.

## Prerequisites
- Java JDK 17 installation