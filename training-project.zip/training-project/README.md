# BA-SWE TalentHub Training catalog

## Welcome to the Novatec TalentHub!

This repository provides everything you will need on your way to be a professional software engineer.
Here we want to give you the chance to get in touch with programming languages, tooling, frameworks, etc.

Take your time and deep dive into professional development. The exercises are functional which means that
they won't have a lot of business (use-case) complexity. It is all about the frameworks and tools and having
time to get in touch with more details.

Please make sure that you take down all your theoretical and practical research and implementations. Of course,
we want to see, discuss and verify them together in code reviews.

## How to start

- Go to the [GitLab repository](https://gitlab.novatec-gmbh.de/talent-hub/trainingcatalog/training-project) and clone
  the project to a local repository via `HTTPS` or `SSH` (you might need to set up a key, first). You can use git in
  a terminal or the integration of the IDE of your choice
- Create a new local branch from `main` with the following name pattern: `<YOUR_NOVATEC_SHORTNAME>_training_catalog`.
- Put all your implementations in the according packages `src/main/java` respectively `src/main/kotlin`
- If you have finished a task, commit those changes to your local branch and push it to the remote repository,
  afterwards. This way we can take a look into the results from time to time, give feedback or set up an appointment
  for a bigger code review
- You will find more details in the separate chapter descriptions

## Persons Responsible

- Marcel Lengl
- Olaf Versteeg

## Useful links

- TalentHub Landing page: https://confluence.novatec-gmbh.de/display/EAD/DPD+Talent+Hub
- Overview about our topics:
  - https://confluence.novatec-gmbh.de/display/EAD/Talent+Hub%3A+How+we+work
  - https://confluence.novatec-gmbh.de/display/EAD/Talent+Hub%3A+Experience+Level
- GitLab repository: https://gitlab.novatec-gmbh.de/talent-hub/trainingcatalog/training-project
- TalentHub team organisation: https://confluence.novatec-gmbh.de/display/EAD/Talent+Hub%3A+Organisation

---

## Change History

| Date       | User          | Note                                   |
|------------|---------------|----------------------------------------|
| 27.01.2022 | Marcel Lengl  | Initial polish and future safe-upgrade |
| 25.01.2023 | Olaf Versteeg | Refining of the tasks                  |
